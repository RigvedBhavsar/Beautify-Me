import React from 'react';
import aboutUs from '../images/aboutUs.jpg';
const About = () => {
    return (
        <section id="about">
            <div className="about-us">

                <div className="aboutleft">
                    <img src={aboutUs} className="arms" alt="pic"></img>
                </div>
                <div className="aboutright">
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <b>Hello Beauties !</b> Pooja here.💭Welcome to this beautiful world 
                    also thank you for visiting my website! 
                    <br></br><br></br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    About me, I started my professional makeup artistry business, in 2017.I am a certified makeup artis. 
                    Beside that I'm also have been a pharmacy student as well.
                    When I tell people my background I'm always asked, how did you end up in makeup with that type of background?
                    Well I ended up in makeup Because its my passion and I also learnt alot about cosmetics in my pharmacy course 
                    so its helping me now to launch my own products in this world of beauty.
                    <br></br><br></br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    Now that I have given you a little bit about me, let me tell you about my business.
                    I am here to service all your beauty needs. If you're looking for special occasion makeup for that engagement 
                    session, wedding, birthday, headshot, or a date night, book me as your makeup artist. I will be hosting one on 
                    one makeup lessons, having group classes, and I will be assisting with personal shopping. 
                    Be sure you stay tuned to my website for updates on classes, and events!
                    <br></br><br></br>
                    <b>Thank you!</b>&nbsp;&nbsp;🧠
                </div>
            </div>
        </section>
    )
}

export default About
