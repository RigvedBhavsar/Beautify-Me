import React from 'react'

const Appointment = () => {
    return (
        <div>
           <h1> Appointment</h1>
        </div>
    )
}

export default Appointment
