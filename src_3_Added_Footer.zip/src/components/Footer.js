import React from 'react'

const Footer = () => {
    return (
        <footer class="page-footer footer">
          <div class="container footer-main">
            <div class="row">
              <div class="col l3 s12">
                <h6 class="white-text">BEAUTIFY ME</h6>
                <ul>
                    <li><a class="grey-text text-lighten-4" href="#!">About</a></li>
                    <li><a class="grey-text text-lighten-4" href="#!">Contact</a></li>
                </ul>
              </div>
              <div class="col l3 s12">
                <h6 class="white-text">NEED HELP ?</h6>
                <p class="grey-text text-lighten-4">support@beautifyme.com</p>
                <p class="grey-text text-lighten-4">+91 88888 88888</p>
              </div>
              
              <div class="col l4 offset-l2 s12">
                <h6 class="white-text">CUSTOMER CARE</h6> 
                <ul>
                  <li><a class="grey-text text-lighten-3" href="#!">Terms & Conditions</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">FAQ's</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Privacy Policy</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Return Policy</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright footer-copy">
            <div class="container">
           Copyright © 2021 | Beautify Me
            </div>
          </div>
        </footer>
    )
}

export default Footer
