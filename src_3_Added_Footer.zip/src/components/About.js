import React from 'react'

const About = () => {
    return (
        <div>
            <h1>ABout US</h1>
        </div>
    )
}

export default About
