import React, { useState , useEffect} from "react";
import DatePicker from "react-date-picker";
import TimePicker from "react-time-picker";

import Select from 'react-select';
import M from 'materialize-css';
import './Appointment.css';
const Appointment = () => {

    const available= [
        {value:'SPA' , label:'SPA'},
        {value:'Hair cut' , label:'Hair Cut'},
        {value:'Manicure' , label:'ManiCure'},
        {value:'Padicure' , label:'Padicure'},
        {value:'Waxing' , label:'Waxing'},
        {value:'Straightning' , label:'Straightning'},
        {value:'Hair Coloring' , label:'Hair Coloring'},
        {value:'Highlights' , label:'Highlights'},
        {value:'Facial' , label:'Facial'},
        {value:'Acne Treatment' , label:'Acne Treatment'},
        {value:'Massage' , label:'Massage'},
        {value:'Event Makeup' , label:'Event Makeup'},
        {value:'Wedding Makeup' , label:'Wedding Makeup'},
        {value:'Mehandi' , label:'Mehandi'},
    ];
    
    const [date, setDate] = useState(new Date());
    const [time, setTime] = useState('10:15');
    const [name , setName] = useState("");
    const [service ,setService] = useState(available.value);
    
    const makeAppointment = ()=>{
        console.log(name);
        console.log( date);
        console.log(time);
        console.log(service);
        alert("Appointment Booked");
    }
    
    const assignValue = e =>{
        setService(e.value);
    }


    return (
        <div className="my-card-appt">
            <div className="card auth-card-appt input-field">
                <h4 className="font">Book Appointment</h4>
                <input type="text" placeholder="Booking For" value={name} onChange={(e)=>setName(e.target.value)}/>       
                
                <div className="row">
                <div className="left">
                    <div className="datetime">
                        <DatePicker onChange={setDate} value={date} />
                    </div>
                    <div className="datetime" style={{justifyContent:"left"}}>
                        <TimePicker onChange={setTime} value={time} placeholder="Select Date" />                   
                    </div>
                </div>
                <div className="right">
                    <div className="datetime">
                        <Select className="drop-down-style" options ={available}  onChange={assignValue} placeholder="Select Service"/>
                    </div>
                </div>
                </div>

                <div>
                    <button className="waves-light btn #f57f17 yellow darken-4" onClick={()=>makeAppointment()}>Book</button>
                </div>
                
            </div>
        </div>
    )
}
export default Appointment
