import React, { useContext } from 'react'
import { Link} from 'react-router-dom';
import { UserContext } from '../App';
const Navbar = () => {

    const {state , dispatch }  = useContext(UserContext); 
    const renderList=()=>{
        if(state){
            return[
                <li className="center" id="brand-logo">
                    <Link to="/">
                    Beautify Me</Link></li>,
                <li className="center"><Link to="/products">Products</Link></li>,
                <li className="center"><Link to="/appoinment">Appointment</Link></li>,
                <li className="center"><Link to="/about">About</Link></li>,
                <li className="center"><Link to="/contact">Contact</Link></li>
            ]
        }else{
            return[
                <li className="center" id="brand-logo">
                    <Link to="/">
                    Beautify Me</Link></li>,
                <li className="center"><Link to="/products">Products</Link></li>,
                <li className="center"><Link to="/appoinment">Appointment</Link></li>,
                <li className="center"><Link to="/about">About</Link></li>,
                <li className="center"><Link to="/contact">Contact</Link></li>
            ]
        }
    }

    return(
        <div> 
            <nav className="navbar">
                <div className="nav-wrapper">
                    <Link to={state? "/":"/signin"}></Link>
                    <ul id="nav-mobile">
                        {renderList()}
                    </ul>
                </div>
            </nav>
        </div>
    )
}

export default Navbar
