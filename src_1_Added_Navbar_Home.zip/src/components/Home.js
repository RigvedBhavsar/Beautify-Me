import React from 'react'

const Home=() =>{
    return (
        <div className="home">
            <div style={{marginTop:"250px"}}>
                <h1 style={{color:"white" , height:"55px"}}>NEED A NEW LOOK ?</h1>
                <h4 style={{color:"white"}} >WE ARE YOUR SOLUTION</h4>
                <h5>We Want To Be Your Destination For Great Beauty</h5>
            </div>
        </div>
    )
}

export default Home
